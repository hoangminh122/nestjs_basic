
export interface StudentDTO {
    studentId: string;
    classId: string;
    firstName: string;
    lastName: string;
    dod: Date;
    sex: string;
    address: string;
    avatarId: string;
    active: string;
}