
export interface UserDTO {
    firstName: string;
    lastName: string;
    email: string;
    username: string;
    password: string;
    avatarId: string;
}