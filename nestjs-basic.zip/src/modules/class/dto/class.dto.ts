
export interface ClassDTO {
    code: string;
    name: string;
    description: string;
}